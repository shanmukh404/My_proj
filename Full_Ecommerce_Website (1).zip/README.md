
# 🛍️ Full-Stack E-commerce Website

This is a fully functional e-commerce platform with:
- React Frontend (Vite)
- Node.js + Express Backend
- MongoDB Database
- Stripe Payment (Sandbox)
- JWT Authentication (Login/Register)
- Cart and Checkout System

---

## 🧾 Features

- Product listing and details
- Add to cart and quantity management
- Checkout and fake payment via Stripe sandbox
- Secure login/register with JWT
- Admin routes starter

---

## ⚙️ Setup Instructions

### 1. Clone & Install Dependencies

```bash
unzip Full_Ecommerce_Website.zip
cd ecommerce-site

# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

### 2. Setup `.env` Files

Rename `.env.example` to `.env` in `/server` and add:
```
MONGO_URI=mongodb://localhost:27017/ecommerce
JWT_SECRET=your_jwt_secret
STRIPE_SECRET_KEY=your_stripe_test_key
```
> Replace with your real Stripe test key

### 3. Run Project

**Backend** (port 5000):

```bash
cd server
npm run dev
```

**Frontend** (port 5173):

```bash
cd ../client
npm run dev
```

---

## 🌍 Deployment Guide

- Backend: [Render.com](https://render.com) (Free tier)
- Frontend: [Vercel](https://vercel.com)
- MongoDB: [MongoDB Atlas](https://www.mongodb.com/cloud/atlas)

---

## 🔐 Admin Panel (Next Steps)

You can expand this project with:
- Admin login with a separate role
- Product create/edit/delete routes
- Order management dashboard

Let me know if you want this built as well!
